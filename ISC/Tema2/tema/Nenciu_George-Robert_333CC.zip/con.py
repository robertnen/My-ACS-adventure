import socket

port = 13939
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(("0.0.0.0", port))
server.listen(7)

print(f"{port} e ascultat...")

while True:
    client, address = server.accept()
    print(f"Conexiune de la {address}")

    message = client.recv(1024).decode("utf-8")
    print(f"Mesaj: {message}")

    client.close()
    break

server.close()